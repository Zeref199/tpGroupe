/* ************************************* */
/* ********       IMPORTS       ******** */
/* ************************************* */
import { combineReducers } from 'redux';
import { BreadcrumbReducer } from '@beyond-framework/common-uitoolkit-beyond';
import computedMenuReducer from './scenes/Home/components/reducer';

/* ************************************* */
/* ********      VARIABLES      ******** */
/* ************************************* */
const reducers = combineReducers({
    breadcrumb: BreadcrumbReducer,
    computedMenu: computedMenuReducer,
});

/* ************************************* */
/* ********  PRIVATE FUNCTIONS  ******** */
/* ************************************* */

/* ************************************* */
/* ********   PUBLIC FUNCTIONS  ******** */
/* ************************************* */

/* ************************************* */
/* ********       EXPORTS       ******** */
/* ************************************* */
export default reducers;
