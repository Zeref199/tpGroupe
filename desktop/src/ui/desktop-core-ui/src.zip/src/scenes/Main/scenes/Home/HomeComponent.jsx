/* ************************************* */
/* ********       IMPORTS       ******** */
/* ************************************* */
import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { DesktopBreadcrumbPart } from '@beyond-framework/common-uitoolkit-beyond';
// import AuthProvider from 'common-base-auth-javascript';
// import moment from 'moment';

import 'moment/locale/es'
import 'moment/locale/fr'

import './style.scss';


// const FR_LANG = 'fr';
// const EN_LANG = 'en';
// const DEFAULT_LANG = FR_LANG;


/* ************************************* */
/* ********      VARIABLES      ******** */
/* ************************************* */

// function setLang() {
//     try{
//         const lang = localStorage.getItem('i18nextLng');
//
//         const computedLang = lang && lang.startsWith('en') ? EN_LANG : DEFAULT_LANG;
//
//         moment.locale(computedLang)
//     } catch(err){
//         return DEFAULT_LANG;
//     }
// }

// function handleDate() {
//     setLang();
//     let date = moment().format('dddd D MMMM YYYY');
//     date = date.charAt(0).toUpperCase() + date.slice(1);
//     return date;
// }
/* ************************************* */
/* ********      COMPONENT      ******** */
/* ************************************* */
const HomeComponent = ({ t, shouldDisplayLogo }) => {
    // const firstName = (AuthProvider && AuthProvider.getUserInfo() && AuthProvider.getUserInfo().firstName) || 'Admin';
    return (
        <Fragment>
            <DesktopBreadcrumbPart label={t('breadcrumb.Home')} />
            <div className="global-flexbox">
                {/*<div className="headers-style">*/}
                {/*    <h1 className="pl-29-px mb-0 pt-4 hello-font-size">{`${t('landingPage.hello')} ${firstName} !`}</h1>*/}
                {/*    <h2 className="pl-29-px mt-0 date-font-size">{handleDate()}</h2>*/}
                {/*</div>*/}
                {/*<div className="logo-style">*/}
                {/*    {shouldDisplayLogo && <img src={logo} alt="Beyond Logo" width="217" height="239" />}*/}
                {/*</div>*/}
                {/*<div className="all-favorites-style">*/}
                {/*    <h1>hi</h1>*/}
                {/*</div>*/}
            </div>
        </Fragment>
    );
};

HomeComponent.propTypes = {
    t: PropTypes.func,
    shouldDisplayLogo: PropTypes.bool,
};

/* ************************************* */
/* ********       EXPORTS       ******** */
/* ************************************* */
export default HomeComponent;
