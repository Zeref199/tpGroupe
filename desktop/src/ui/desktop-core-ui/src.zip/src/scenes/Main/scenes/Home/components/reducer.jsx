import types from './types';

const initialState = {
    menuLoading: false,
};

function reducer(state = initialState, action) {
    switch (action.type) {
        case types.GET_MENU_ENTRIES_PENDING.type:
        case types.GET_FAVORITES_MENU_ENTRIES_PENDING.type:
            return {
                ...state,
                menuLoading: true,
            };
        case types.GET_MENU_ENTRIES_FULFILLED.type:
        case types.GET_FAVORITES_MENU_ENTRIES_FULFILLED.type:
            return {
                ...state,
                menuLoading: false,
            };
        case types.GET_MENU_ENTRIES_REJECTED.type:
        case types.GET_FAVORITES_MENU_ENTRIES_REJECTED.type:
            return {
                ...state,
                menuLoading: false,
            };

        default:
            return state;
    }
}

export default reducer;
